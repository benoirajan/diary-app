import { useReducer, useEffect } from "react";

/*
  =========================
  Initial State
  =========================
*/
const initialState = {
  entries: [],
  loading: false,
  error: null,
};

/*
  =========================
  Reducer
  =========================
*/
const entryReducer = (state, action) => {
  switch (action.type) {
    case "LOAD_START":
      return { ...state, loading: true, error: null };

    case "LOAD_SUCCESS":
      return { ...state, loading: false, entries: action.payload };

    case "LOAD_ERROR":
      return { ...state, loading: false, error: action.payload };

    case "ADD_ENTRY":
      return {
        ...state,
        entries: [action.payload, ...state.entries],
      };

    case "UPDATE_ENTRY":
      return {
        ...state,
        entries: state.entries.map((entry) =>
          entry.id === action.payload.id ? action.payload : entry
        ),
      };

    case "DELETE_ENTRY":
      return {
        ...state,
        entries: state.entries.filter(
          (entry) => entry.id !== action.payload
        ),
      };

    default:
      return state;
  }
};

/*
  =========================
  Custom Hook
  =========================
*/
export const useEntries = () => {
  const [state, dispatch] = useReducer(entryReducer, initialState);

  /*
    =========================
    LocalStorage Persistence
    =========================
  */
  useEffect(() => {
    dispatch({ type: "LOAD_START" });

    try {
      const stored = localStorage.getItem("diary_entries");
      const parsed = stored ? JSON.parse(stored) : [];

      dispatch({ type: "LOAD_SUCCESS", payload: parsed });
    } catch (error) {
      dispatch({
        type: "LOAD_ERROR",
        payload: "Failed to load entries",
      });
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "diary_entries",
      JSON.stringify(state.entries)
    );
  }, [state.entries]);

  /*
    =========================
    Actions
    =========================
  */

  const addEntry = (entry) => {
    const newEntry = {
      ...entry,
      id: crypto.randomUUID(),
      date: entry.date || new Date().toISOString(),
    };

    dispatch({ type: "ADD_ENTRY", payload: newEntry });
  };

  const updateEntry = (updatedEntry) => {
    dispatch({ type: "UPDATE_ENTRY", payload: updatedEntry });
  };

  const deleteEntry = (id) => {
    dispatch({ type: "DELETE_ENTRY", payload: id });
  };

  return {
    entries: state.entries,
    loading: state.loading,
    error: state.error,
    addEntry,
    updateEntry,
    deleteEntry,
  };
};